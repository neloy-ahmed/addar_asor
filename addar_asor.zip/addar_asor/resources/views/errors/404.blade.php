@extends('templates.default')

@section('content')
    <h3>OOPs That page could not be found</h3>
    <a href="{{ route('home') }}">go home</a>
@stop