@extends('templates.default')

@section('content')
    <h3>Welcome to ADDAR ASOR</h3>
    <p>The best social network ever</p>
@stop