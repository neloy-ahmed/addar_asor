<?php $__env->startSection('content'); ?>
    <h3>Welcome to ADDAR ASOR</h3>
    <p>The best social network ever</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>